import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  SafeAreaView,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 20,
    alignItems: 'center',
  },
  headerText: {
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
  },
  bookList: {
    padding: 10,
  },
  bookItem: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flexDirection: 'row',
  },
  bookImage: {
    width: 80,
    height: 120,
    marginRight: 10,
  },
  bookTitle: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  bookAuthor: {
    color: 'white',
    fontSize: 16,
  },
  bookPages: {
    color: 'white',
    fontSize: 16,
  },
  bookGenre: {
    color: 'white',
    fontSize: 16,
  },
  bookDescription: {
    color: 'white',
    fontSize: 14,
  },
  statistics: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  statisticsText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  lastRead: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 0,
    padding: 10,
    marginBottom: 10,
  },
  lastReadText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default function App() {
  const [books, setBooks] = useState([
    {
      id: '1',
      title: 'Hunger Games Catching Fire',
      author: 'Suzanne Collins',
      image: require('./assets/book.jpg'),
      pages: 400,
      genre: 'Science Fiction',
      description:
        'In the second installment of the Hunger Games series, Katniss Everdeen faces new challenges and adventures in the dystopian world of Panem.',
    },
    {
      id: '2',
      title: 'Harry Potter and The Half Blood Prince',
      author: 'J.K. Rowling',
      image: require('./assets/harryp.jpg'),
      pages: 600,
      genre: 'Fantasy',
      description:
        'Join Harry, Ron, and Hermione in their sixth year at Hogwarts as they uncover dark secrets and prepare to face the dark wizard Lord Voldemort.',
    },
    {
      id: '3',
      title: 'The Hobbit',
      author: 'J.R.R. Tolkien',
      image: require('./assets/hobbits.jpg'),
      pages: 300,
      genre: 'Fantasy',
      description:
        'Follow Bilbo Baggins on an unexpected adventure as he joins a group of dwarves on a quest to reclaim their homeland from the dragon Smaug.',
    },
    // Add more book data as needed
  ]);

  // Calculate the total and average pages read
  const totalPagesRead = books.reduce((total, book) => total + book.pages, 0);
  const averagePagesRead = totalPagesRead / books.length;

  // Get the last 3 read books
  const lastReadBooks = books.slice(-3).reverse();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      <View style={styles.header}>
        <Text style={styles.headerText}>Thobeka's Book Archives</Text>
      </View>

      <View style={styles.lastRead}>
        <Text style={styles.lastReadText}>History</Text>
      </View>

      <FlatList
        data={lastReadBooks}
        style={styles.bookList}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.bookItem}>
            <Image source={item.image} style={styles.bookImage} />
            <View>
              <Text style={styles.bookTitle}>{item.title}</Text>
              <Text style={styles.bookAuthor}>Author: {item.author}</Text>
              <Text style={styles.bookPages}>Pages: {item.pages}</Text>
              <Text style={styles.bookGenre}>Genre: {item.genre}</Text>
              <Text style={styles.bookDescription}>{item.description}</Text>
            </View>
          </View>
        )}
      />

      <View style={styles.statistics}>
        <Text style={styles.statisticsText}>Total Pages Read: {totalPagesRead}</Text>
        <Text style={styles.statisticsText}>
          Average Pages Read: {averagePagesRead.toFixed(2)}
        </Text>
      </View>
    </SafeAreaView>
  );
}
