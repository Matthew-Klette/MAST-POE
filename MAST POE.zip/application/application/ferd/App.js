import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  FlatList,
  TextInput,
} from 'react-native';
import { StatusBar } from 'react-native';
import { Picker } from '@react-native-picker/picker';


const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 20,
    alignItems: 'center',
  },
  headerText: {
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
  },
  bookList: {
    padding: 10,
  },
  bookItem: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flexDirection: 'column',
    alignItems: 'center',
    height: 400,
  },
  bookItem1: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flexDirection: 'column',
    alignItems: 'center',
    height: 70,
  },

  bookItem2: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    flexDirection: 'column',
    alignItems: 'center',
    height: 300,
   
  },
  
  bookImage: {
    width: 100,
    height:150,
    marginBottom: 10,
  },
  bookInfo: {
    flex: 1,
    alignItems: 'center',
  },
  bookTitle: {
    color: 'white',
    fontSize: 25,
    fontWeight: 'bold',
  },
  bookAuthor: {
    color: 'white',
    fontSize: 20,
  },
  bookGenre: {
    color: 'white',
    fontSize: 18,
  },
  bookPages: {
    color: 'white',
    fontSize: 18,
  },
  bookDescription: {
    color: 'white',
    fontSize: 18,
  },
  statisticsContainer: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 10,
    marginBottom: 10,
    alignItems: 'center',
  },
  statisticsText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  textInput: {
    backgroundColor: 'rgba(10, 50, 0, 0.2)',
    width: '90%',
    height: 100,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    paddingLeft: 10,
  },
  pickerContainer: {
    marginBottom: 0,
    width: 450,
  },
  picker: {
    borderWidth: 3,
    borderColor: 'black',
    backgroundColor: 'white',
    fontSize: 40,
    height: 60,
    margin: 20,
    opacity: 0.8,
  },
  history: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  historyText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  lastRead: {
    backgroundColor: 'rgba(10, 50, 0, 0.5)',
    borderRadius: 0,
    padding: 10,
    marginBottom: 10,
  },
  lastReadText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  buttonContainer: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    width: '45%',
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  showButtonsContainer: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    borderRadius: 0,
    padding: 10,
    marginBottom: 5,
    width: '100%',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
  },
  showButtonsText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subheading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'white',
  },//IIE(2023).
  history: {
    backgroundColor: 'rgba(10, 50, 0, 0.7)',
    padding: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  historyText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

const booksData = [
  {
    id: '1',
    title: 'Hunger Games Catching Fire',
    author: 'Suzanne Collins',
    image: require('./assets/book.jpg'),
    pages: 400,
    genre: 'Science Fiction',
    description:
      'In the second installment of the Hunger Games series, Katniss Everdeen faces new challenges and adventures in the dystopian world of Panem.',
  },
  //IIE(2023).
];

const genres = [
  'Select A Genre:',
  'Fantasy',
  'Fiction',
  'Horror',
  'Thriller',
  'Science Fiction',
  'Romance',
  'Drama',
  'Other',
]; //IIE(2023).

export default function App() {
  const [books, setBooks] = useState(booksData);
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    description: '',
    genre: 'Select A Genre',
  });
  const [recentlyAddedBooks, setRecentlyAddedBooks] = useState([]);
  const [showButtons, setShowButtons] = useState(false);
  const [currentScreen, setCurrentScreen] = useState('Home');

  const totalPagesRead = books.reduce((total, book) => total + parseInt(book.pages, 10), 0);
  const averagePagesRead = books.length > 0 ? totalPagesRead / books.length : 0;

  const addBook = () => {
    const updatedBooks = [...books];
    const newBookIndex = updatedBooks.length;

    updatedBooks[newBookIndex] = { ...newBook, id: String(newBookIndex + 1) };

    setNewBook({ title: '', author: '', description: '', genre: '' });
    setBooks(updatedBooks);

    setRecentlyAddedBooks([updatedBooks[newBookIndex], ...recentlyAddedBooks]);
  };

  const calculatePagesByGenre = () => {
    const pagesByGenre = {};

    books.forEach((book) => {
      const genre = book.genre;

      if (!pagesByGenre[genre]) {
        pagesByGenre[genre] = 0;
      }

      pagesByGenre[genre] += parseInt(book.pages, 10);
    });

    return pagesByGenre;
  };

  const pagesByGenre = calculatePagesByGenre();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      <View style={styles.header}>
        <Text style={styles.headerText}>
          {currentScreen === 'Home'
            ? "Thobeka's Book Archives"
            : currentScreen === 'History'
            ? "Thobeka's Book History"
            : 'Add a Book'}
        </Text>
      </View>
      <View style={styles.statisticsContainer}>
        <Text style={styles.statisticsText}>Total Pages Read: {totalPagesRead}</Text>
        <Text style={styles.statisticsText}>
          Average Pages Read: {averagePagesRead.toFixed(2)}
        </Text>
      </View>
      {currentScreen === 'Home' && (
        <View>
          <FlatList
            data={books}
            style={styles.bookList}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.bookItem}>
                <Image source={item.image} style={styles.bookImage} />
                <View style={styles.bookInfo}>
                  <Text style={styles.bookTitle}>{item.title}</Text>
                  <Text style={styles.bookAuthor}>Author: {item.author}</Text>
                  <Text style={styles.bookGenre}>Genre: {item.genre}</Text>
                  <Text style={styles.bookPages}>Pages: {item.pages}</Text>
                  <Text style={styles.bookDescription}>{item.description}</Text>
                </View>
              </View>
            )}
          />
        </View>
      )}
      {currentScreen === 'History' ? (
        <View>
          <Text style={styles.historyText}>Recently Added Books</Text>
          <FlatList
            data={recentlyAddedBooks.slice(0, 3).reverse()}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.bookItem2}>
                <Image source={item.image} style={styles.bookImage} />
                <View style={styles.bookInfo}>
                  <Text style={styles.bookTitle}>{item.title}</Text>
                  <Text style={styles.bookAuthor}>Author: {item.author}</Text>
                  <Text style={styles.bookGenre}>Genre: {item.genre}</Text>
                  <Text style={styles.bookPages}>Pages: {item.pages}</Text>
                  <Text style={styles.bookDescription}>{item.description}</Text>
                </View>
              </View>
            )}
          />
        </View>
      ) : currentScreen === 'AddBook' ? (
        <View style={{ alignItems: 'center' }}>
          <Text style={styles.subheading}>Add a Book Subheading</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Title"
            value={newBook.title}
            onChangeText={(text) => setNewBook({ ...newBook, title: text })}
          />
          <TextInput
            style={styles.textInput}
            placeholder="Author"
            value={newBook.author}
            onChangeText={(text) => setNewBook({ ...newBook, author: text })}
          />
          <TextInput
            style={styles.textInput}
            placeholder="Pages"
            value={newBook.pages}
            onChangeText={(text) => setNewBook({ ...newBook, pages: text })}
          />
          <View style={styles.pickerContainer}>
            <View style={styles.picker}>
              <Picker
                selectedValue={newBook.genre}
                onValueChange={(itemValue) => setNewBook({ ...newBook, genre: itemValue })}
              >
                {genres.map((genre) => (
                  <Picker.Item key={genre} label={genre} value={genre} />
                ))}
              </Picker>
            </View>
          </View>
          <TouchableOpacity style={styles.buttonContainer} onPress={addBook}>
            <Text style={styles.buttonText}>Add Book</Text>
          </TouchableOpacity>
        </View>
      ) : currentScreen === 'Genre' ? (
       
        <View style={styles.bookList}>
          {Object.keys(pagesByGenre).map((genre) => (
            <View key={genre} style={styles.bookItem1}>
              <Text style={styles.bookGenre}>{genre}</Text>
              <Text style={styles.bookPages}>Pages Read: {pagesByGenre[genre]}</Text>
            </View>
          ))}
        </View>
      ) : null}
    
      
      <View style={styles.showButtonsContainer}>
        <TouchableOpacity
          style={styles.buttonContainer}
          onPress={() => setShowButtons(!showButtons)}
        >
          <Text style={styles.showButtonsText}>
            {showButtons ? 'Hide Menu' : 'Show Menu'}
          </Text>
        </TouchableOpacity>
        {showButtons && (
          <View style={styles.buttonGrid}>
            <TouchableOpacity
              style={styles.buttonContainer}
              onPress={() => setCurrentScreen('Home')}
            >
              <Text style={styles.buttonText}>Home</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.buttonContainer}
              onPress={() => setCurrentScreen('History')}
            >
              <Text style={styles.buttonText}>History</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.buttonContainer}
              onPress={() => setCurrentScreen('AddBook')}
            >
              <Text style={styles.buttonText}>Add a Book</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.buttonContainer}
              onPress={() => setCurrentScreen('Genre')}
            >
              <Text style={styles.buttonText}>Genre</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}/*IIE(2023).
The IIE. 2023. Mobile App Scripting [MAST5112/d/w MODULE MANUAL]. The 
Independent Institute of Education: Unpublished.*/